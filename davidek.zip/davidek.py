#!/usr/bin/env python3

#import tweepy
import csv
from collections import Counter
import argparse
import sys

parser = argparse.ArgumentParser(description='Diplomova prace 2020, David Chvala.')
parser.add_argument('-w', nargs=1, help='most used words', type=int)
args = parser.parse_args()
if (args.w is not None):
	word_list = []
	with open('tweety leave.csv', 'r') as f:
		reader = csv.reader(f, delimiter=';')
		for row in reader:
		#print(row[2])
			word_list = word_list + (row[2].split(' '))
	print(word_list)
	Counter = Counter(word_list) 
  
	# most_common() produces k frequently encountered 
	# input values and their respective counts. 
	most_occur = Counter.most_common(int(args.w[0]))   
	print(most_occur) 
	f = open("words_usage.csv", "w+")
	f.seek(0)
	f.truncate()
	for item in most_occur:
		f.write(item[0] + ";" + str(item[1]) + "\r\n")


#print(my_list[4][2])
		#my_list.append(myClass(row[0], row[1], row[2:]))


"""auth = tweepy.OAuthHandler("jHGrDFY7Nky3TlvhZTzjqpU5l", "iLj1OFkBTGgv0wnow8QJBzkIPuKvTG4gkGtYsN8BJr3Fdq1Wk5")
auth.set_access_token("1191327321225154562-oSCWgvCvXi7qDBpqepDIY4MfEqnKwn", "oUMeXTdwcG2ZKTFYIk3RBNwRTka2DSY6s4j5SRWJ10ULN")

api = tweepy.API(auth)

for tweet in tweepy.Cursor(api.user_timeline,id='AndrejBabis',tweet_mode="extended").items():
	print(tweet.text)"""




"""user = api.get_user('AndrejBabis')
print(user.screen_name)
print(user.followers_count)
for friend in user.friends():
   print(friend.screen_name)"""